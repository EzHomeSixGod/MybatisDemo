create function cost_of_order(orderNo varchar(64))
  returns int unsigned
  BEGIN
	DECLARE ft,cph,mpd,ppd INT UNSIGNED DEFAULT 0;
	DECLARE iCost,iStatus INT UNSIGNED DEFAULT 0;
	DECLARE ct TIMESTAMP ;
	
	DECLARE dd,hh,mm INT UNSIGNED;
	DECLARE dt TIMESTAMP DEFAULT (select now());
	DECLARE diff INT UNSIGNED;
	
	# MCFISH:获取消费规则
	select value into ft from tb_system_config where `key` = 'free_time';
	select value into cph from tb_system_config where `key` = 'cost_per_hour';
	select value into mpd from tb_system_config where `key` = 'max_per_day';
	select value into ppd from tb_system_config where `key` = 'price_per_device';
	
	# MCFISH:订单为空
	IF orderNo is null THEN
		RETURN 0;
	END IF;

	# MCFISH:获取订单信息
	select tb.cost, tb.status, tb.create_time into iCost, iStatus, ct from tb_user_borrow tb where tb.order_no = orderNo;
	IF iCost is null THEN
		SET iCost = 0;
	END IF;
	
	# MCFISH:已结束的订单，直接返回消费的价格
	IF iStatus = 2 THEN
		RETURN iCost;
	END IF;

	# MCFISH:未结束的订单，动态计算价格
	SET diff = timestampdiff(SECOND, ct, dt);
	# update tb_user_borrow set used_time=floor(diff/60) where order_no = orderNo;

	SET dd = floor(diff / 86400);
	IF dd > 0 THEN
		SET iCost = iCost + dd * mpd;
	END IF;

	SET hh = floor((diff % 86400) / 3600);
	IF hh > 0 THEN
		IF hh * cph > mpd THEN
			SET iCost = iCost + mpd;
		ELSE
			SET iCost = iCost + hh * cph;
		END IF;
	END IF;

	SET mm = floor((diff % 3600) / 60);
	IF iCost > 0 and mm > 0 THEN
		SET iCost = iCost + cph;
	END IF;
	
	IF iCost = 0 and mm > ft THEN
		SET iCost = iCost + cph;
	END IF;

	# MCFISH:超过了整个充电宝的价格，则固定为充电宝的价格
	IF iCost > ppd THEN
		SET iCost = ppd;
	END IF;

	RETURN iCost;
	# RETURN CONCAT_WS("&", CAST(diff as char), CAST(dd as char),CAST(hh as char), CAST(mm as char), CAST(iCost as char));
END;

