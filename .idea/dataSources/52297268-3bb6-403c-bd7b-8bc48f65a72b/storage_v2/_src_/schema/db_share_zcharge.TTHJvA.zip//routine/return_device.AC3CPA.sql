create function return_device(pSNO varchar(32), pDNO varchar(32), pPOS tinyint unsigned)
  returns int
  BEGIN
	# 订单信息
	DECLARE orderNo VARCHAR(64);
	DECLARE orderCost INT;
	DECLARE dt TIMESTAMP DEFAULT (select now());
	
	# 用户信息
	DECLARE uid INT UNSIGNED;
	DECLARE ret INT;
	DECLARE iMoney,iDeposit INT UNSIGNED;

	# 代理商信息
	DECLARE shopId, agentId, staffId INT UNSIGNED;

	# 设备信息
	DECLARE devId,devStat INT UNSIGNED DEFAULT 0;
	
	# 优惠券信息
	DECLARE cpId, cpMoney INT UNSIGNED DEFAULT 0;

	# MCFISH: 先判断是否为新设备
	select id,status into devId,devStat from tb_dev_device where dno=pDNO limit 1;
	IF devId = 0 or devId is null THEN
		insert into tb_dev_device(dno) values(pDNO);
	END IF;

	# MCFISH: 更新机柜仓位（不论是新设备，还是归还设备）
	update tb_dev_position set dno=NULL where dno=pDNO;
	update tb_dev_position set dno=pDNO where sno=pSNO and `position`=pPOS;
	
	# 是新增设备，不做后面的逻辑
	IF devId = 0 or devId is null THEN
		RETURN 1;
	END IF; 


	# MCFISH: 非故障设备，更新为正常
	IF devStat != 2 THEN
		update tb_dev_device set status=0 where dno=pDNO;
	END IF;

	# MCFISH: 获取待结算的订单
	select order_no,user_id,cost_of_order(order_no) into orderNo,uid,orderCost from tb_user_borrow where dno=pDNO and status=1 order by create_time desc limit 1;
	IF orderNo is null THEN
		RETURN -2;
	END IF;

	# MCFISH: 结束记录
	update tb_user_borrow set cost=orderCost,used_time=timestampdiff(MINUTE, create_time, dt),status=2 where order_no=orderNo;

	
	# MCFISH: 计算费用
	# ------------------------------------------------------
	IF orderCost is null or orderCost = 0 THEN
		RETURN 2;
	END IF;

	IF orderCost <= 0 THEN
		RETURN 0;
	END IF;

	# 从余额中扣除用户的相关费用
	select money, deposit into iMoney, iDeposit from tb_user where id = UID limit 1;
	
	# MCFISH: 扣除用户的余额,余额不足不扣款
	IF iMoney >= orderCost THEN

    # 选择最早的优惠券来抵扣部分金额
		select tb_user_coupon.id,tb_system_coupon.money into cpId,cpMoney from tb_user_coupon left join tb_system_coupon on tb_user_coupon.coupon_id = tb_system_coupon.id where tb_user_coupon.user_id = uid and tb_user_coupon.status=0 order by tb_user_coupon.create_time desc limit 1;
		IF cpId is not null THEN
			IF orderCost >= cpMoney THEN
				SET orderCost = orderCost - cpMoney;
			ELSE
				SET orderCost = 0;
			END IF;
			update tb_user_coupon set order_no=orderNo,status=1 where id=cpId;
		END IF;

		update tb_user set money = money - orderCost where id = UID;
		insert into tb_user_money(user_id, order_no, type, money, money_after, status, comment,coupon_id) values(UID, orderNo, 3, orderCost, iMoney - orderCost, 1, '余额消费',cpId);
	ELSE
		#update tb_user set money=0, deposit=iDeposit + iMoney - orderCost where id = UID;
		#insert into tb_user_money(user_id, order_no, type, money, money_after, status, comment) values(UID, orderNo, 3, iMoney, 0, 1, '从押金扣除部分费用');
		update tb_user_borrow tb set tb.status=4 where tb.order_no=orderNo LIMIT 1;
	END IF;

	# MCFISH:【查机柜表】
	select T.shop_id, S.agent_id into shopId, agentId from tb_dev_cabinet as T left join tb_shop as S on T.shop_id = S.id where T.sno = pSNO limit 1;

	# MCFISH: 结算费用
	select share_profit(shopId, agentId, orderNo, orderCost) into ret;
	RETURN ret;
END;

