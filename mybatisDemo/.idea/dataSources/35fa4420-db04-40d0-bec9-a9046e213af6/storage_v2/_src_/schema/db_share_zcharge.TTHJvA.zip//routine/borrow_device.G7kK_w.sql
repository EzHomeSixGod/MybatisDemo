create function borrow_device(pSNO varchar(32), pPOS tinyint unsigned, pDNO varchar(32))
  returns int
  BEGIN
	# 订单信息
	DECLARE orderNo VARCHAR(64);
	DECLARE dt TIMESTAMP DEFAULT date_sub(NOW(), interval 2 minute);

	# MCFISH:更新机柜状态，被借出
	update tb_dev_position set dno=null where sno=pSNO and `position`=pPOS;

	# MCFISH:更新设备状态
	update tb_dev_device set status=1 where dno=pDNO;

	# MCFISH:获取设备所在订单,2分钟以内
	select order_no into orderNo from tb_user_borrow where dno=pDNO and status=0 and create_time >= dt ORDER BY create_time DESC LIMIT 1;
	IF orderNo is null THEN
		RETURN -1;
	END IF;

	# MCFISH:更新订单状态，借成功
	update tb_user_borrow set status=1 where order_no=orderNo;

	RETURN 0;
END;

