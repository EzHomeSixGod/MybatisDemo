create function init_device(pSNO varchar(32))
  returns int
  BEGIN
	DECLARE cId VARCHAR(64);

	# MCFISH: 判断是否为新设备
	select id into cId from tb_dev_cabinet where sno=pSNO limit 1;
	IF cId is not null THEN
		RETURN 0;
	END IF;

	# MCFISH: 创建一个新的设备
	insert into tb_dev_cabinet(sno, online) values(pSNO, 1);
	
	# MCFISH: 为机柜创建10个仓位
	insert into tb_dev_position(sno, position) values
		(pSNO, 1), (pSNO, 2), (pSNO, 3), (pSNO, 4), (pSNO, 5),
		(pSNO, 6), (pSNO, 7), (pSNO, 8), (pSNO, 9), (pSNO, 10);

	RETURN 0;
END;

