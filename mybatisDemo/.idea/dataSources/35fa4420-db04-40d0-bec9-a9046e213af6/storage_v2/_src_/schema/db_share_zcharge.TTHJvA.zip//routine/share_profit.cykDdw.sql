create function share_profit(shopId int unsigned, agentId int unsigned, orderNo varchar(64), cost int unsigned)
  returns int
  BEGIN
	# 代理商信息
	DECLARE fatherId INT UNSIGNED;
	DECLARE fcShop, fcAgent, fcStaff, fcLast INT UNSIGNED DEFAULT 0;
	DECLARE aid,fc,times INT UNSIGNED DEFAULT 0;

	# 如果消费小于10分，则不做处理
	if cost < 10 THEN
		RETURN 0;
	END IF;

	# MCFISH：优先给商家分成
	IF shopId is not null THEN
		select proportion into fcShop from tb_shop where id = shopId limit 1;
		if fcShop > 0 and fcShop <= 100 THEN
			insert into tb_shop_money(shop_id, order_no, amount) values(shopId, orderNo, cost * fcShop / 100);
			SET fcLast = fcShop;
		END IF;
	END IF;

	# MCFISH: 代理商佣金，多级收益
	SET aid = agentId;
	W:WHILE aid is not null and times < 3 DO
		select father_id, proportion into fatherId, fcAgent from tb_agent where id = aid limit 1;
		IF fcAgent > 0 THEN
			# 异常处理
			if fcAgent < fcLast THEN
				LEAVE W;
			END IF;
			
			# 小于5里，不分
			SET fc = FLOOR(cost * (fcAgent - fcLast) / 100);
			if fc > 0 THEN
				insert into tb_agent_money(agent_id, order_no, amount) values(aid, orderNo, fc);
			END IF;
		END IF;

		SET fcLast = fcAgent;
		SET aid    = fatherId;
		
		# 异常处理
		SET times = times + 1;
	END WHILE;
	
	# MCFISH：将剩余的钱放入到系统收益中
	IF fcLast < 100 THEN
		SET fc = FLOOR(cost * (100 - fcLast) / 100);
		insert into tb_system_money(order_no, money) values(orderNo, fc);
	END IF;

	# 返回结果
	RETURN 0;
END;

